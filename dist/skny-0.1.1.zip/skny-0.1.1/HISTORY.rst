=======
History
=======

0.1.0 (2024-01-21)
------------------

* First release on PyPI.
