"""Main module."""
from .preprocessing.distance_calculator import calculate_distance

