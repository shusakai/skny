=====
Usage
=====

To use skny in a project::

    import skny
